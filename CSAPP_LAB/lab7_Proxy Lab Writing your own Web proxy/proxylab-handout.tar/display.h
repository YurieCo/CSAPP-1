
int init_display_window (int argc, char ** argv);
int destroy_window ( );
int change_display (int new_num);


int bitAnd(int, int);
int test_bitAnd(int, int);






int bitXor(int, int);
int test_bitXor(int, int);






int evenBits();
int test_evenBits();






int getByte(int, int);
int test_getByte(int, int);






int bitMask(int, int);
int test_bitMask(int, int);






int reverseBytes(int);
int test_reverseBytes(int);






int leastBitPos(int);
int test_leastBitPos(int);






int logicalNeg(int);
int test_logicalNeg(int);







int minusOne();
int test_minusOne();






int tmax();
int test_tmax();






int negate(int);
int test_negate(int);






int isPositive(int);
int test_isPositive(int);






int isLess(int, int);
int test_isLess(int, int);






int sm2tc(int);
int test_sm2tc(int);






